<template>
	<div class="header">
		<div style="width:100%;height:0.1rem;background:#f5f4f9"></div>
	</div>
</template>

<script type="text/ecmascript">
	
	export default {
		data () {
			return {
				msg: "我是组件模板的数据"
			}
		}
	}
</script>

<!--<style lang="less" rel="stylesheet/less" scoped>

</style>
<style lang="stylus" rel="stylesheet/stylus">

</style>-->