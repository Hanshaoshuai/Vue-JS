//
//
//export function path(){
//	var URL = {
//		path: 'http://www.qironghome.com/api/index.php', 
//		path2: 'http://www.qironghome.com/index.php', //不用授权的接口地址
//		path3: 'http://www.qironghome.com/index.php/app/' //h5分享页面的地址
//	
//	// 	path: 'http://47.93.63.26/zbq/web/api/index.php', //接口地址
//	// 	path2: 'http://47.93.63.26/zbq/web/index.php', //不用授权的接口地址
//	// 	path3: 'http://47.93.63.26/zbq/web/index.php/app/' //h5分享页面的地址	
//	   	
//	// 	path: 'http://test.qironghome.com/zbq/web/api/index.php', //接口地址
//	// 	path2: 'http://test.qironghome.com/zbq/web/index.php', //不用授权的接口地址
//	// 	path3: 'http://test.qironghome.com/zbq/web/index.php/app/' //h5分享页面的地址	2
//	   	
//	// 	path: 'http://192.168.16.100/zbq/web/api/index.php', //接口地址
//	//  path2: 'http://192.168.16.100/zbq/web/index.php', //不用授权的接口地址
//	//  path3: 'http://192.168.16.100/zbq/web/index.php/app/' //h5分享页面的地址
//	}
//	return URL;
//}
export var URL = {
//	path: 'http://www.qironghome.com/api/index.php/', 
//	path2: 'http://www.qironghome.com/index.php/', //不用授权的接口地址
//	path3: 'http://www.qironghome.com/index.php/app/' //h5分享页面的地址

   	path: 'http://192.168.2.61/bak/web/api/index.php/v2/', //接口地址
   	path2: 'http://47.93.63.26/zbq/web/index.php', //不用授权的接口地址
   	path3: 'http://47.93.63.26/zbq/web/index.php/app/' //h5分享页面的地址	
   	
// 	path: 'http://test.qironghome.com/zbq/web/api/index.php', //接口地址
// 	path2: 'http://test.qironghome.com/zbq/web/index.php', //不用授权的接口地址
// 	path3: 'http://test.qironghome.com/zbq/web/index.php/app/' //h5分享页面的地址	2
   	
// 	path: 'http://192.168.16.100/zbq/web/api/index.php', //接口地址
//  path2: 'http://192.168.16.100/zbq/web/index.php', //不用授权的接口地址
//  path3: 'http://192.168.16.100/zbq/web/index.php/app/' //h5分享页面的地址
}



